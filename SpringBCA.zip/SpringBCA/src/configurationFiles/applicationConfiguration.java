package configurationFiles;

public class applicationConfiguration {

}
